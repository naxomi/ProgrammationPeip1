#!/usr/bin/env python
#-*- coding: utf-8 -*- 

##########################################################################

''' ----- Exercice 1 ----- '''

def Affine(a,b,x):
    return a*x+b

print(Affine(1, 1, 1))