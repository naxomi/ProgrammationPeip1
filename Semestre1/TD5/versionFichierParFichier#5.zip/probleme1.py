#!/usr/bin/env python
#-*- coding: utf-8 -*- 

##########################################################################

''' ----- Problème 1 ----- '''
    
def audioActive(terme):

    chiffreActuel = terme[0]
    compteurDeChiffres = 0
    nouveauTerme = ""
    
    for chiffre in terme:
        if chiffre == chiffreActuel:
            compteurDeChiffres += 1
        else:
            nouveauTerme += str(compteurDeChiffres) + chiffreActuel
            chiffreActuel = chiffre
            compteurDeChiffres = 1
    
    nouveauTerme += str(compteurDeChiffres) + chiffreActuel
    
    return nouveauTerme
        
nbIteration = int(input("Combien de termes (>= 2) ? : "))

terme = "1"
print("Terme 1 : ", terme)

for loop in range(1, nbIteration):
    terme = audioActive(terme)
    print(f"Terme {loop + 1} : ", terme)