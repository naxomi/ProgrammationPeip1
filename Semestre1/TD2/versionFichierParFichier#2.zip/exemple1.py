''' --- Exemple 1 --- '''

print(' --- Exemple 1 --- ')

prix = int(input("prix ? "))   #1
if prix > 1000 :          #2 instruction if
    print("trop cher")
    print("j'achète pas")
print("fin des achats")   #3
