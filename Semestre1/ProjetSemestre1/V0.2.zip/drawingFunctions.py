'''
Fichier contenant toutes les fonctions permettant de dessiner des formes
'''

from turtle import *
from math import sqrt, sin, radians

def va(x, y, turtleDrawing):
	turtleDrawing.up()
	turtleDrawing.goto(x, y)
	turtleDrawing.down()

def draw_star(x, y, length, shapeColor, turtleDrawing):

	# --- Initialize the position and color of the turtle --- #
	va(x, y, turtleDrawing)
	turtleDrawing.color(shapeColor)

	# --- Start drawing --- #
	turtleDrawing.begin_fill()

	turtleDrawing.setheading(36)
	for loop in range(5):
		turtleDrawing.forward(length)
		turtleDrawing.right(72)
		turtleDrawing.forward(length)
		turtleDrawing.left(144)

	turtleDrawing.end_fill()
	# --- End drawing --- #

def draw_oval(centerX, centerY, length, cornersize, shapeColor, turtleDrawing):
	# --- Initialize the position, orientation and color of the turtle --- #
	turtleDrawing.setheading(270)
	turtleDrawing.color(shapeColor)
	va(centerX - cornersize, centerY - length/2, turtleDrawing)

	# --- Start drawing --- #
	turtleDrawing.circle(cornersize, 180)
	turtleDrawing.fd(length)
	turtleDrawing.circle(cornersize, 180)
	turtleDrawing.fd(length)
	# --- End drawing --- #

def draw_rectangle(length, width, shapeColor, turtleDrawing):

	# --- Initialize the color of the turtle --- #
	turtleDrawing.color(shapeColor)

	# --- Start drawing --- #
	turtleDrawing.begin_fill()

	for loop in range(2):
		turtleDrawing.fd(length)
		turtleDrawing.left(90)
		turtleDrawing.fd(width)
		turtleDrawing.left(90)

	turtleDrawing.end_fill()
	# --- End drawing --- #

def draw_triangle(length1, length2, length3, angle1, angle2, angle3, color, turtleDrawing):

	# --- Start drawing --- #
	turtleDrawing.begin_fill()

	turtleDrawing.setheading(angle1)
	turtleDrawing.fd(length1)
	turtleDrawing.setheading(angle2)
	turtleDrawing.fd(length2)
	turtleDrawing.setheading(angle3)
	turtleDrawing.fd(length3)

	turtleDrawing.end_fill()
	# --- End drawing --- #

def half_grid(turtleDrawing):

	# --- Initialize the color of the turtle --- #
	turtleDrawing.color("black")

	# --- Start drawing --- #
	turtleDrawing.up()
	turtleDrawing.goto(0,-500)
	turtleDrawing.down()
	turtleDrawing.setheading(90)
	turtleDrawing.fd(1000)
	turtleDrawing.up()
	turtleDrawing.setheading(0)

	turtleDrawing.goto(-500,0)
	turtleDrawing.down()
	turtleDrawing.setheading(0)
	turtleDrawing.fd(1000)
	turtleDrawing.up()
	turtleDrawing.setheading(0)
	# --- End drawing --- #

def point_color(startColor, endColor, turtleDrawing):

	# --- Start drawing --- #
	turtleDrawing.color(startColor)
	turtleDrawing.dot(10)
	turtleDrawing.color(endColor)
	# --- End drawing --- #

def draw_round_rectangle(x, y, width, height, cornersize, shapeColor, turtleDrawing):
	
	# --- Initialize the position and color of the turtle --- #
	va(x + cornersize, y, turtleDrawing)
	turtleDrawing.color(shapeColor)

	# --- Start drawing --- #
	turtleDrawing.begin_fill()

	for loop in range(2):
		turtleDrawing.fd(width - 2*cornersize)
		turtleDrawing.circle(cornersize, 90)
		turtleDrawing.fd(height - 2*cornersize)
		turtleDrawing.circle(cornersize, 90)

	turtleDrawing.end_fill()
	# --- End drawing --- #

def draw_rectangle_reversed_angle(shapeColor, signLength, signWidth, cornersize, turtleDrawing):

	# --- Initialize the position and color of the turtle --- #
	va(turtleDrawing.position()[0] + cornersize, turtleDrawing.position()[1], turtleDrawing)
	turtleDrawing.color(shapeColor)
	
	# --- Start drawing --- #
	turtleDrawing.begin_fill()

	turtleDrawing.fd(signLength - 2*cornersize)
	turtleDrawing.setheading(270)
	turtleDrawing.circle(cornersize, -90)
	turtleDrawing.setheading(90)
	turtleDrawing.fd(signWidth - 2*cornersize)
	turtleDrawing.setheading(0)
	turtleDrawing.circle(cornersize, -90)
	turtleDrawing.setheading(180)
	turtleDrawing.fd(signLength - 2*cornersize)
	turtleDrawing.setheading(90)
	turtleDrawing.circle(cornersize, -90)
	turtleDrawing.setheading(270)
	turtleDrawing.fd(signWidth - 2*cornersize)
	turtleDrawing.setheading(180)
	turtleDrawing.circle(cornersize, -90)

	turtleDrawing.end_fill()
	# --- End drawing --- #
