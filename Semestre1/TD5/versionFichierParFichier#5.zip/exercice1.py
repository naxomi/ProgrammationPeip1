#!/usr/bin/env python
#-*- coding: utf-8 -*- 

##########################################################################

''' ----- Exercice 1 ----- '''

mot = input("un mot : ")
i = 0

while i < len(mot):
   print(mot[i])
   i = i + 2