#!/usr/bin/env python
#-*- coding: utf-8 -*- 

##########################################################################

''' ----- Exercice 1 ----- '''

l = ["fraise","kiwi",[12,34,56],5.34,"bonjour"]

print(l[1])
print(l[2])
print(l[2][1])
print(l[1:3])
print(l[3:5])
print(l)
l.append("adieu")
print(l)